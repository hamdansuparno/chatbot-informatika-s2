# Aplikasi Penggajian Tkinter

## Fitur
- Data Golongan: tambah, edit, hapus.
- Data Karyawan: tambah, edit, hapus, pencarian.
- Transaksi Gaji: gaji pokok otomatis dari golongan; tunjangan, lembur, potongan; total otomatis.
- Cetak Slip: menyimpan slip transaksi terpilih sebagai TXT yang siap dicetak.
- Laporan Excel dan PDF.
- Database MySQL `dbsistem`.

## Instalasi
1. Jalankan XAMPP dan Start MySQL.
2. Pastikan MySQL menggunakan user `root` tanpa password. Jika berbeda, ubah `DB_CONFIG` di `aplikasi_gaji.py`.
3. Buka CMD di folder ini:
   `pip install -r requirements.txt`
4. Jalankan:
   `python aplikasi_gaji.py`

Aplikasi otomatis membuat database/tabel jika belum ada dan mengisi contoh golongan.
