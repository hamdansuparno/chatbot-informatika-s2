import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from decimal import Decimal, InvalidOperation
from datetime import datetime
import mysql.connector
from mysql.connector import Error

APP_TITLE = "Sistem Penggajian Karyawan"
DB_CONFIG = {"host": "localhost", "user": "root", "password": "", "database": "dbsistem"}

def db():
    return mysql.connector.connect(**DB_CONFIG)

def rupiah(v):
    try:
        return f"Rp {Decimal(str(v)):,.0f}".replace(",", ".")
    except Exception:
        return "Rp 0"

def ensure_db():
    c = mysql.connector.connect(host=DB_CONFIG["host"], user=DB_CONFIG["user"], password=DB_CONFIG["password"])
    cur = c.cursor()
    cur.execute("CREATE DATABASE IF NOT EXISTS dbsistem")
    cur.close(); c.close()
    c = db(); cur = c.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS golongan(
        id_golongan INT AUTO_INCREMENT PRIMARY KEY,
        kode_golongan VARCHAR(20) NOT NULL UNIQUE,
        nama_golongan VARCHAR(80) NOT NULL,
        gaji_pokok DECIMAL(15,2) NOT NULL DEFAULT 0)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS karyawan(
        id_karyawan INT AUTO_INCREMENT PRIMARY KEY,
        nik VARCHAR(30) NOT NULL UNIQUE,
        nama_karyawan VARCHAR(120) NOT NULL,
        jabatan VARCHAR(100),
        id_golongan INT NOT NULL,
        FOREIGN KEY(id_golongan) REFERENCES golongan(id_golongan))""")
    cur.execute("""CREATE TABLE IF NOT EXISTS gaji(
        id_gaji INT AUTO_INCREMENT PRIMARY KEY,
        id_karyawan INT NOT NULL,
        periode VARCHAR(7) NOT NULL,
        gaji_pokok DECIMAL(15,2) NOT NULL,
        tunjangan DECIMAL(15,2) NOT NULL DEFAULT 0,
        lembur DECIMAL(15,2) NOT NULL DEFAULT 0,
        potongan DECIMAL(15,2) NOT NULL DEFAULT 0,
        total_gaji DECIMAL(15,2) NOT NULL,
        tanggal_transaksi TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(id_karyawan) REFERENCES karyawan(id_karyawan))""")
    c.commit(); cur.close(); c.close()

def seed():
    c=db(); cur=c.cursor()
    cur.execute("SELECT COUNT(*) FROM golongan")
    if cur.fetchone()[0] == 0:
        cur.executemany("INSERT INTO golongan(kode_golongan,nama_golongan,gaji_pokok) VALUES(%s,%s,%s)",
                        [("I/A","Golongan I A",3000000),("II/A","Golongan II A",4000000),
                         ("III/A","Golongan III A",5000000),("IV/A","Golongan IV A",6500000)])
    c.commit(); cur.close(); c.close()

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE); self.geometry("1180x720"); self.minsize(1050,650)
        self.selected_karyawan=None; self.selected_golongan=None; self.selected_gaji=None
        self.configure(bg="#eef2f7")
        self.style=ttk.Style(self); self.style.theme_use("clam")
        self.style.configure("Treeview", rowheight=28, font=("Segoe UI",10))
        self.style.configure("Treeview.Heading", font=("Segoe UI",10,"bold"))
        self.style.configure("TButton", font=("Segoe UI",10), padding=7)
        self.style.configure("TLabel", background="#eef2f7", font=("Segoe UI",10))
        self.build()
        self.refresh_all()

    def build(self):
        head=tk.Frame(self,bg="#17365d",height=72); head.pack(fill="x")
        tk.Label(head,text="SISTEM PENGGAJIAN KARYAWAN",fg="white",bg="#17365d",
                 font=("Segoe UI",20,"bold")).pack(anchor="w",padx=22,pady=(12,0))
        tk.Label(head,text="Database: dbsistem  |  Python + Tkinter + MySQL",fg="#d9e8ff",bg="#17365d",
                 font=("Segoe UI",9)).pack(anchor="w",padx=24)
        nb=ttk.Notebook(self); nb.pack(fill="both",expand=True,padx=12,pady=12)
        self.tab_gol=ttk.Frame(nb); self.tab_kar=ttk.Frame(nb); self.tab_gaji=ttk.Frame(nb); self.tab_lap=ttk.Frame(nb)
        nb.add(self.tab_gol,text="  Golongan  "); nb.add(self.tab_kar,text="  Karyawan  ")
        nb.add(self.tab_gaji,text="  Transaksi Gaji  "); nb.add(self.tab_lap,text="  Laporan / Slip  ")
        self.build_gol(); self.build_kar(); self.build_gaji(); self.build_lap()

    def tree(self,parent,cols,widths):
        box=ttk.Frame(parent); box.pack(fill="both",expand=True,padx=12,pady=8)
        t=ttk.Treeview(box,columns=cols,show="headings")
        for c,w in zip(cols,widths): t.heading(c,text=c); t.column(c,width=w,anchor="center")
        sy=ttk.Scrollbar(box,orient="vertical",command=t.yview); t.configure(yscrollcommand=sy.set)
        t.pack(side="left",fill="both",expand=True); sy.pack(side="right",fill="y")
        return t

    def build_gol(self):
        f=ttk.LabelFrame(self.tab_gol,text="Form Golongan"); f.pack(fill="x",padx=12,pady=10)
        self.gkode=tk.StringVar(); self.gnama=tk.StringVar(); self.gpokok=tk.StringVar()
        for i,(lab,var) in enumerate([("Kode",self.gkode),("Nama Golongan",self.gnama),("Gaji Pokok",self.gpokok)]):
            ttk.Label(f,text=lab).grid(row=0,column=i*2,padx=6,pady=8,sticky="w")
            ttk.Entry(f,textvariable=var,width=25).grid(row=0,column=i*2+1,padx=6,pady=8)
        ttk.Button(f,text="Simpan",command=self.save_gol).grid(row=0,column=6,padx=5)
        ttk.Button(f,text="Edit",command=self.edit_gol).grid(row=0,column=7,padx=5)
        ttk.Button(f,text="Hapus",command=self.delete_gol).grid(row=0,column=8,padx=5)
        ttk.Button(f,text="Bersihkan",command=self.clear_gol).grid(row=0,column=9,padx=5)
        self.tgol=self.tree(self.tab_gol,("ID","Kode","Nama","Gaji Pokok"),[70,120,300,180])
        self.tgol.bind("<<TreeviewSelect>>",self.pick_gol)

    def build_kar(self):
        f=ttk.LabelFrame(self.tab_kar,text="Form Karyawan"); f.pack(fill="x",padx=12,pady=10)
        self.knik=tk.StringVar(); self.knama=tk.StringVar(); self.kjab=tk.StringVar(); self.kgol=tk.StringVar()
        labels=[("NIK",self.knik),("Nama",self.knama),("Jabatan",self.kjab)]
        for i,(lab,var) in enumerate(labels):
            ttk.Label(f,text=lab).grid(row=0,column=i*2,padx=6,pady=8,sticky="w")
            ttk.Entry(f,textvariable=var,width=25).grid(row=0,column=i*2+1,padx=6,pady=8)
        ttk.Label(f,text="Golongan").grid(row=0,column=6,padx=6)
        self.kcombo=ttk.Combobox(f,textvariable=self.kgol,width=28,state="readonly"); self.kcombo.grid(row=0,column=7,padx=6)
        ttk.Button(f,text="Simpan",command=self.save_kar).grid(row=0,column=8,padx=4)
        ttk.Button(f,text="Edit",command=self.edit_kar).grid(row=0,column=9,padx=4)
        ttk.Button(f,text="Hapus",command=self.delete_kar).grid(row=0,column=10,padx=4)
        ttk.Button(f,text="Bersihkan",command=self.clear_kar).grid(row=0,column=11,padx=4)
        s=ttk.Frame(self.tab_kar); s.pack(fill="x",padx=12)
        ttk.Label(s,text="Cari:").pack(side="left"); self.ksearch=tk.StringVar()
        ttk.Entry(s,textvariable=self.ksearch,width=35).pack(side="left",padx=6)
        ttk.Button(s,text="Cari",command=self.load_kar).pack(side="left"); ttk.Button(s,text="Semua",command=lambda:self.load_kar("")).pack(side="left",padx=4)
        self.tkar=self.tree(self.tab_kar,("ID","NIK","Nama","Jabatan","Golongan","Gaji Pokok"),[60,120,220,170,110,150])
        self.tkar.bind("<<TreeviewSelect>>",self.pick_kar)

    def build_gaji(self):
        f=ttk.LabelFrame(self.tab_gaji,text="Input Transaksi Gaji"); f.pack(fill="x",padx=12,pady=10)
        self.gkar=tk.StringVar(); self.periode=tk.StringVar(value=datetime.now().strftime("%Y-%m"))
        self.tunj=tk.StringVar(value="0"); self.lembur=tk.StringVar(value="0"); self.pot=tk.StringVar(value="0"); self.total=tk.StringVar(value="0")
        ttk.Label(f,text="Karyawan").grid(row=0,column=0,padx=6,pady=8); self.gcombo=ttk.Combobox(f,textvariable=self.gkar,width=38,state="readonly"); self.gcombo.grid(row=0,column=1,padx=6); self.gcombo.bind("<<ComboboxSelected>>",self.calc)
        ttk.Label(f,text="Periode").grid(row=0,column=2,padx=6); ttk.Entry(f,textvariable=self.periode,width=12).grid(row=0,column=3,padx=6)
        for i,(lab,var) in enumerate([("Tunjangan",self.tunj),("Lembur",self.lembur),("Potongan",self.pot)]):
            ttk.Label(f,text=lab).grid(row=1,column=i*2,padx=6,pady=8); ttk.Entry(f,textvariable=var,width=18).grid(row=1,column=i*2+1,padx=6)
        ttk.Label(f,text="TOTAL").grid(row=1,column=6,padx=6); ttk.Entry(f,textvariable=self.total,width=18,state="readonly").grid(row=1,column=7,padx=6)
        ttk.Button(f,text="Simpan Transaksi",command=self.save_gaji).grid(row=1,column=8,padx=5)
        ttk.Button(f,text="Cetak Slip",command=self.slip_selected).grid(row=1,column=9,padx=5)
        ttk.Button(f,text="Hapus",command=self.delete_gaji).grid(row=1,column=10,padx=5)
        self.tgaji=self.tree(self.tab_gaji,("ID","Periode","NIK","Nama","Pokok","Tunjangan","Lembur","Potongan","Total"),[55,85,110,190,120,120,110,110,140])
        self.tgaji.bind("<<TreeviewSelect>>",self.pick_gaji)
        for v in (self.tunj,self.lembur,self.pot): v.trace_add("write",lambda *a:self.calc())

    def build_lap(self):
        top=ttk.Frame(self.tab_lap); top.pack(fill="x",padx=12,pady=15)
        ttk.Button(top,text="Ekspor Excel",command=self.export_excel).pack(side="left",padx=5)
        ttk.Button(top,text="Ekspor PDF",command=self.export_pdf).pack(side="left",padx=5)
        ttk.Button(top,text="Cetak Slip Transaksi Terpilih",command=self.slip_selected).pack(side="left",padx=5)
        ttk.Button(top,text="Refresh",command=self.load_gaji).pack(side="left",padx=5)
        tk.Label(self.tab_lap,text="Laporan diambil dari seluruh transaksi pada tabel gaji.",bg="#eef2f7",
                 font=("Segoe UI",11)).pack(anchor="w",padx=20,pady=10)

    def clear_gol(self):
        self.selected_golongan=None; self.gkode.set(""); self.gnama.set(""); self.gpokok.set("")
    def clear_kar(self):
        self.selected_karyawan=None; self.knik.set(""); self.knama.set(""); self.kjab.set(""); self.kgol.set("")
    def getmoney(self,s):
        return Decimal(s.replace(".","").replace(",","").replace("Rp","").strip() or "0")
    def load_gol(self):
        self.tgol.delete(*self.tgol.get_children()); c=db(); cur=c.cursor()
        cur.execute("SELECT id_golongan,kode_golongan,nama_golongan,gaji_pokok FROM golongan ORDER BY id_golongan")
        for r in cur.fetchall(): self.tgol.insert("", "end", values=(r[0],r[1],r[2],rupiah(r[3])))
        cur.close(); c.close()
        c=db(); cur=c.cursor(); cur.execute("SELECT id_golongan,kode_golongan,nama_golongan FROM golongan ORDER BY kode_golongan")
        self.gcombo["values"]=[f"{r[0]} | {r[1]} - {r[2]}" for r in cur.fetchall()]
        self.kcombo["values"]=self.gcombo["values"]; cur.close(); c.close()
    def pick_gol(self,_=None):
        x=self.tgol.selection()
        if not x:return
        r=self.tgol.item(x[0],"values"); self.selected_golongan=r[0]; self.gkode.set(r[1]); self.gnama.set(r[2]); self.gpokok.set(r[3].replace("Rp ","").replace(".",""))
    def save_gol(self):
        try:
            val=self.getmoney(self.gpokok.get())
            c=db(); cur=c.cursor(); cur.execute("INSERT INTO golongan(kode_golongan,nama_golongan,gaji_pokok) VALUES(%s,%s,%s)",(self.gkode.get(),self.gnama.get(),val)); c.commit(); cur.close(); c.close(); self.clear_gol(); self.refresh_all(); messagebox.showinfo("Sukses","Golongan disimpan.")
        except Exception as e: messagebox.showerror("Error",str(e))
    def edit_gol(self):
        if not self.selected_golongan:return messagebox.showwarning("Pilih","Pilih golongan.")
        try:
            c=db();cur=c.cursor();cur.execute("UPDATE golongan SET kode_golongan=%s,nama_golongan=%s,gaji_pokok=%s WHERE id_golongan=%s",(self.gkode.get(),self.gnama.get(),self.getmoney(self.gpokok.get()),self.selected_golongan));c.commit();cur.close();c.close();self.clear_gol();self.refresh_all()
        except Exception as e:messagebox.showerror("Error",str(e))
    def delete_gol(self):
        if not self.selected_golongan:return
        if not messagebox.askyesno("Konfirmasi","Hapus golongan ini?"):return
        try:
            c=db();cur=c.cursor();cur.execute("DELETE FROM golongan WHERE id_golongan=%s",(self.selected_golongan,));c.commit();cur.close();c.close();self.clear_gol();self.refresh_all()
        except Exception as e:messagebox.showerror("Tidak dapat dihapus", "Golongan mungkin masih dipakai karyawan.\n"+str(e))
    def load_kar(self,_=None):
        q=self.ksearch.get(); self.tkar.delete(*self.tkar.get_children()); c=db();cur=c.cursor()
        cur.execute("""SELECT k.id_karyawan,k.nik,k.nama_karyawan,k.jabatan,g.kode_golongan,g.gaji_pokok
                    FROM karyawan k JOIN golongan g ON k.id_golongan=g.id_golongan
                    WHERE k.nik LIKE %s OR k.nama_karyawan LIKE %s OR k.jabatan LIKE %s ORDER BY k.id_karyawan""",(f"%{q}%",f"%{q}%",f"%{q}%"))
        for r in cur.fetchall():self.tkar.insert("", "end",values=(r[0],r[1],r[2],r[3],r[4],rupiah(r[5])))
        cur.close();c.close()
    def pick_kar(self,_=None):
        x=self.tkar.selection()
        if not x:return
        r=self.tkar.item(x[0],"values");self.selected_karyawan=r[0];self.knik.set(r[1]);self.knama.set(r[2]);self.kjab.set(r[3]); 
        for v in self.kcombo["values"]:
            if f" | {r[4]} -" in v:self.kgol.set(v);break
    def save_kar(self):
        try:
            gid=int(self.kgol.get().split("|")[0].strip());c=db();cur=c.cursor();cur.execute("INSERT INTO karyawan(nik,nama_karyawan,jabatan,id_golongan) VALUES(%s,%s,%s,%s)",(self.knik.get(),self.knama.get(),self.kjab.get(),gid));c.commit();cur.close();c.close();self.clear_kar();self.refresh_all();messagebox.showinfo("Sukses","Karyawan disimpan.")
        except Exception as e:messagebox.showerror("Error",str(e))
    def edit_kar(self):
        if not self.selected_karyawan:return messagebox.showwarning("Pilih","Pilih karyawan.")
        try:
            gid=int(self.kgol.get().split("|")[0].strip());c=db();cur=c.cursor();cur.execute("UPDATE karyawan SET nik=%s,nama_karyawan=%s,jabatan=%s,id_golongan=%s WHERE id_karyawan=%s",(self.knik.get(),self.knama.get(),self.kjab.get(),gid,self.selected_karyawan));c.commit();cur.close();c.close();self.clear_kar();self.refresh_all()
        except Exception as e:messagebox.showerror("Error",str(e))
    def delete_kar(self):
        if not self.selected_karyawan:return
        if not messagebox.askyesno("Konfirmasi","Hapus karyawan ini?"):return
        try:
            c=db();cur=c.cursor();cur.execute("DELETE FROM karyawan WHERE id_karyawan=%s",(self.selected_karyawan,));c.commit();cur.close();c.close();self.clear_kar();self.refresh_all()
        except Exception as e:messagebox.showerror("Tidak dapat dihapus","Karyawan mungkin sudah memiliki transaksi gaji.\n"+str(e))
    def load_gaji(self):
        self.tgaji.delete(*self.tgaji.get_children());c=db();cur=c.cursor()
        cur.execute("""SELECT g.id_gaji,g.periode,k.nik,k.nama_karyawan,g.gaji_pokok,g.tunjangan,g.lembur,g.potongan,g.total_gaji
                    FROM gaji g JOIN karyawan k ON g.id_karyawan=k.id_karyawan ORDER BY g.id_gaji DESC""")
        for r in cur.fetchall():self.tgaji.insert("", "end",values=(r[0],r[1],r[2],r[3],rupiah(r[4]),rupiah(r[5]),rupiah(r[6]),rupiah(r[7]),rupiah(r[8])))
        cur.close();c.close()
        c=db();cur=c.cursor();cur.execute("SELECT k.id_karyawan,k.nik,k.nama_karyawan FROM karyawan k ORDER BY k.nama_karyawan")
        self.gcombo["values"]=[f"{r[0]} | {r[1]} - {r[2]}" for r in cur.fetchall()];cur.close();c.close()
    def calc(self,*_):
        try:
            if not self.gkar:return
            kid=int(self.gkar.get().split("|")[0].strip());c=db();cur=c.cursor();cur.execute("SELECT g.gaji_pokok FROM karyawan k JOIN golongan g ON k.id_golongan=g.id_golongan WHERE k.id_karyawan=%s",(kid,));r=cur.fetchone();cur.close();c.close()
            if r:self.total.set(str(r[0]+self.getmoney(self.tunj.get())+self.getmoney(self.lembur.get())-self.getmoney(self.pot.get())))
        except: self.total.set("0")
    def save_gaji(self):
        try:
            kid=int(self.gkar.get().split("|")[0].strip());c=db();cur=c.cursor();cur.execute("SELECT g.gaji_pokok FROM karyawan k JOIN golongan g ON k.id_golongan=g.id_golongan WHERE k.id_karyawan=%s",(kid,));r=cur.fetchone()
            if not r:raise ValueError("Karyawan tidak ditemukan")
            pok=Decimal(str(r[0]));t=self.getmoney(self.tunj.get());l=self.getmoney(self.lembur.get());p=self.getmoney(self.pot.get());tot=pok+t+l-p
            cur.execute("INSERT INTO gaji(id_karyawan,periode,gaji_pokok,tunjangan,lembur,potongan,total_gaji) VALUES(%s,%s,%s,%s,%s,%s,%s)",(kid,self.periode.get(),pok,t,l,p,tot));c.commit();cur.close();c.close();self.load_gaji();messagebox.showinfo("Sukses","Transaksi gaji berhasil disimpan.")
        except Exception as e:messagebox.showerror("Error",str(e))
    def pick_gaji(self,_=None):
        x=self.tgaji.selection()
        if x:self.selected_gaji=self.tgaji.item(x[0],"values")[0]
    def delete_gaji(self):
        if not self.selected_gaji:return messagebox.showwarning("Pilih","Pilih transaksi.")
        if not messagebox.askyesno("Konfirmasi","Hapus transaksi terpilih?"):return
        c=db();cur=c.cursor();cur.execute("DELETE FROM gaji WHERE id_gaji=%s",(self.selected_gaji,));c.commit();cur.close();c.close();self.selected_gaji=None;self.load_gaji()
    def get_slip(self):
        if not self.selected_gaji: return None
        c=db();cur=c.cursor(dictionary=True);cur.execute("""SELECT g.*,k.nik,k.nama_karyawan,k.jabatan,gol.kode_golongan
            FROM gaji g JOIN karyawan k ON g.id_karyawan=k.id_karyawan JOIN golongan gol ON k.id_golongan=gol.id_golongan
            WHERE g.id_gaji=%s""",(self.selected_gaji,));r=cur.fetchone();cur.close();c.close();return r
    def slip_selected(self):
        r=self.get_slip()
        if not r:return messagebox.showwarning("Pilih","Pilih transaksi gaji terlebih dahulu.")
        path=filedialog.asksaveasfilename(defaultextension=".txt",filetypes=[("Text","*.txt")],initialfile=f"Slip_Gaji_{r['nik']}_{r['periode']}.txt")
        if not path:return
        text=f"""SLIP GAJI KARYAWAN
========================================
NIK             : {r['nik']}
Nama            : {r['nama_karyawan']}
Jabatan         : {r['jabatan']}
Golongan        : {r['kode_golongan']}
Periode         : {r['periode']}
----------------------------------------
Gaji Pokok      : {rupiah(r['gaji_pokok'])}
Tunjangan       : {rupiah(r['tunjangan'])}
Lembur          : {rupiah(r['lembur'])}
Potongan        : {rupiah(r['potongan'])}
----------------------------------------
TOTAL DITERIMA  : {rupiah(r['total_gaji'])}
Tanggal         : {r['tanggal_transaksi']}
========================================
"""
        Path(path).write_text(text,encoding="utf-8");messagebox.showinfo("Sukses",f"Slip disimpan:\n{path}")
    def export_excel(self):
        try: import openpyxl
        except ImportError:return messagebox.showerror("Library belum ada","Install: pip install openpyxl")
        path=filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Excel","*.xlsx")],initialfile="Laporan_Gaji.xlsx")
        if not path:return
        c=db();cur=c.cursor();cur.execute("""SELECT g.id_gaji,g.periode,k.nik,k.nama_karyawan,k.jabatan,gol.kode_golongan,g.gaji_pokok,g.tunjangan,g.lembur,g.potongan,g.total_gaji
        FROM gaji g JOIN karyawan k ON g.id_karyawan=k.id_karyawan JOIN golongan gol ON k.id_golongan=gol.id_golongan ORDER BY g.id_gaji""");rows=cur.fetchall();cur.close();c.close()
        wb=openpyxl.Workbook();ws=wb.active;ws.title="Laporan Gaji";ws.append(["ID","Periode","NIK","Nama","Jabatan","Golongan","Gaji Pokok","Tunjangan","Lembur","Potongan","Total Gaji"])
        for r in rows:ws.append(list(r))
        for cell in ws[1]:cell.font=openpyxl.styles.Font(bold=True)
        wb.save(path);messagebox.showinfo("Sukses",f"Excel disimpan:\n{path}")
    def export_pdf(self):
        try: from reportlab.lib.pagesizes import A4; from reportlab.platypus import SimpleDocTemplate,Table,TableStyle; from reportlab.lib import colors
        except ImportError:return messagebox.showerror("Library belum ada","Install: pip install reportlab")
        path=filedialog.asksaveasfilename(defaultextension=".pdf",filetypes=[("PDF","*.pdf")],initialfile="Laporan_Gaji.pdf")
        if not path:return
        c=db();cur=c.cursor();cur.execute("""SELECT g.id_gaji,g.periode,k.nik,k.nama_karyawan,g.total_gaji
        FROM gaji g JOIN karyawan k ON g.id_karyawan=k.id_karyawan ORDER BY g.id_gaji""");rows=cur.fetchall();cur.close();c.close()
        doc=SimpleDocTemplate(path,pagesize=A4);data=[["ID","Periode","NIK","Nama","Total Gaji"]]+[[r[0],r[1],r[2],r[3],rupiah(r[4])] for r in rows]
        t=Table(data,repeatRows=1);t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17365d")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.5,colors.grey),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),("VALIGN",(0,0),(-1,-1),"MIDDLE")]))
        doc.build([t]);messagebox.showinfo("Sukses",f"PDF disimpan:\n{path}")
    def refresh_all(self):
        try:self.load_gol();self.load_kar();self.load_gaji()
        except Error as e:messagebox.showerror("Koneksi Database",f"Tidak dapat terhubung ke MySQL.\n\n{e}\n\nPastikan XAMPP MySQL aktif dan database dbsistem tersedia.")

if __name__=="__main__":
    try:
        ensure_db(); seed(); App().mainloop()
    except Exception as e:
        messagebox.showerror("Gagal menjalankan aplikasi",str(e))
