# Python 3D Human World

Game 3D sederhana bergaya sandbox menggunakan Python + Ursina.

## Fitur

- Dunia 3D
- Karakter manusia
- Kamera orang ketiga
- WASD berjalan
- Shift berlari
- Space melompat
- Mouse menggerakkan kamera
- Animasi kaki dan tangan
- NPC
- Rumah
- Pohon
- Jalan
- Kolam
- UI sederhana

## Instalasi Windows

Disarankan Python 3.10/3.11.

Buka Command Prompt di folder proyek:

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

Jika perintah `python` tidak bekerja, coba:

```bash
py -m venv venv
venv\Scripts\activate
py -m pip install -r requirements.txt
py main.py
```

## Kontrol

W A S D  : bergerak
Shift    : lari
Space    : lompat
Mouse    : kamera
Esc      : keluar

## Pengembangan berikutnya

Model manusia `.glb`, pakaian, inventory, kendaraan, senjata/alat,
quest, sistem uang, multiplayer, login, database, dan map besar
dapat ditambahkan setelah versi dasar berjalan.
