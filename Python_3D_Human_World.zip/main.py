from ursina import *
from player import ThirdPersonPlayer
from world import create_world
from npc import NPC

app = Ursina()
window.title = "Python 3D Human World"
window.borderless = False
window.fps_counter.enabled = True
window.exit_button.visible = True

create_world()

player = ThirdPersonPlayer(position=(0, 1, 0))

NPC(position=(8, 1, 8), name="NPC_1")
NPC(position=(-10, 1, 5), name="NPC_2")

# UI
title = Text("PYTHON 3D WORLD", x=-0.85, y=0.45, scale=1.2)
controls = Text(
    "WASD = Jalan | Shift = Lari | Space = Lompat | Mouse = Kamera | Esc = Keluar",
    x=-0.85, y=0.41, scale=0.8
)

def update():
    pass

app.run()
