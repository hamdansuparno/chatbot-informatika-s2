import math
from ursina import *
from player import HumanModel

class NPC(Entity):
    def __init__(self, position=(5,1,5), name="NPC"):
        super().__init__(position=position)
        self.name = name
        self.visual = HumanModel(parent=self)
        self.visual.body.color = color.rgb(180, 80, 80)

        Text(
            text=name,
            parent=self,
            y=2.9,
            origin=(0,0),
            scale=1.2,
            billboard=True
        )

        self.start_x = position[0]
        self.time_offset = position[2]

    def update(self):
        # NPC bergerak bolak-balik sederhana
        self.x = self.start_x + math.sin(time.time() * .8 + self.time_offset) * 3
