from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import math

class HumanModel(Entity):
    """Karakter manusia sederhana yang tersusun dari kepala, badan, tangan dan kaki."""
    def __init__(self, parent=None):
        super().__init__(parent=parent)

        self.body = Entity(parent=self, model='cube', scale=(0.65, 1.05, 0.35),
                           y=1.25, color=color.rgb(45, 90, 180))
        self.head = Entity(parent=self, model='sphere', scale=.52,
                           y=2.15, color=color.rgb(235, 190, 150))

        self.left_arm = Entity(parent=self, model='cube',
                               scale=(0.22, .95, .22), x=-.47, y=1.27,
                               color=color.rgb(235, 190, 150))
        self.right_arm = Entity(parent=self, model='cube',
                                scale=(0.22, .95, .22), x=.47, y=1.27,
                                color=color.rgb(235, 190, 150))

        self.left_leg = Entity(parent=self, model='cube',
                               scale=(.25, 1.0, .28), x=-.19, y=.48,
                               color=color.rgb(35, 35, 55))
        self.right_leg = Entity(parent=self, model='cube',
                                scale=(.25, 1.0, .28), x=.19, y=.48,
                                color=color.rgb(35, 35, 55))

        self.eye_l = Entity(parent=self, model='sphere', scale=.055,
                            x=-.09, y=2.19, z=-.24, color=color.black)
        self.eye_r = Entity(parent=self, model='sphere', scale=.055,
                            x=.09, y=2.19, z=-.24, color=color.black)

class ThirdPersonPlayer(Entity):
    def __init__(self, position=(0,1,0)):
        super().__init__(position=position)

        self.speed = 4
        self.run_speed = 7
        self.jump_power = 7
        self.gravity = 20
        self.vertical_velocity = 0
        self.grounded = True

        self.visual = HumanModel(parent=self)

        self.collider = BoxCollider(self, Vec3(0, 1, 0), Vec3(.8, 2.4, .6))

        self.camera_pivot = Entity(parent=self, y=1.6)
        self.camera_distance = 7
        self.camera_height = 2.0

        camera.parent = self.camera_pivot
        camera.position = (0, self.camera_height, -self.camera_distance)
        camera.rotation = (12, 0, 0)
        camera.fov = 70

        self.walk_time = 0

    def update(self):
        self.handle_movement()
        self.handle_gravity()
        self.update_camera()
        self.animate()

    def handle_movement(self):
        direction = Vec3(
            held_keys['d'] - held_keys['a'],
            0,
            held_keys['w'] - held_keys['s']
        )

        if direction.length() > 0:
            direction = direction.normalized()
            speed = self.run_speed if held_keys['shift'] else self.speed

            # Gerak relatif terhadap arah kamera
            forward = Vec3(camera.forward.x, 0, camera.forward.z).normalized()
            right = Vec3(camera.right.x, 0, camera.right.z).normalized()
            move = (right * direction.x + forward * direction.z)

            if move.length() > 0:
                move = move.normalized()
                self.position += move * speed * time.dt
                self.rotation_y = lerp(self.rotation_y,
                                       math.degrees(math.atan2(move.x, move.z)),
                                       10 * time.dt)

    def handle_gravity(self):
        if self.grounded and held_keys['space']:
            self.vertical_velocity = self.jump_power
            self.grounded = False

        self.vertical_velocity -= self.gravity * time.dt
        self.y += self.vertical_velocity * time.dt

        if self.y <= 1:
            self.y = 1
            self.vertical_velocity = 0
            self.grounded = True

    def update_camera(self):
        # Kamera mengikuti rotasi mouse
        self.camera_pivot.rotation_y += mouse.velocity[0] * 80
        self.camera_pivot.rotation_x -= mouse.velocity[1] * 50
        self.camera_pivot.rotation_x = clamp(
            self.camera_pivot.rotation_x, -10, 35
        )

    def animate(self):
        moving = any([held_keys[k] for k in ['w','a','s','d']])
        if moving:
            self.walk_time += time.dt * (12 if held_keys['shift'] else 8)
            swing = math.sin(self.walk_time) * 25
            self.visual.left_leg.rotation_x = swing
            self.visual.right_leg.rotation_x = -swing
            self.visual.left_arm.rotation_x = -swing * .7
            self.visual.right_arm.rotation_x = swing * .7
        else:
            self.visual.left_leg.rotation_x = 0
            self.visual.right_leg.rotation_x = 0
            self.visual.left_arm.rotation_x = 0
            self.visual.right_arm.rotation_x = 0
