from ursina import *

def create_tree(position=(0,0,0)):
    trunk = Entity(
        model='cube', color=color.rgb(110,70,35),
        scale=(.5, 2.2, .5), position=(position[0], 1.1, position[2])
    )
    leaves = Entity(
        model='sphere', color=color.rgb(40,150,70),
        scale=2.5, position=(position[0], 2.8, position[2])
    )
    return trunk, leaves

def create_house(position=(0,0,0)):
    x, y, z = position

    floor = Entity(model='cube', scale=(7,.3,6),
                   position=(x,.15,z), color=color.rgb(150,120,90))

    back = Entity(model='cube', scale=(7,3.2,.25),
                  position=(x,1.7,z+3), color=color.rgb(210,180,140))
    left = Entity(model='cube', scale=(.25,3.2,6),
                  position=(x-3.5,1.7,z), color=color.rgb(210,180,140))
    right = Entity(model='cube', scale=(.25,3.2,6),
                   position=(x+3.5,1.7,z), color=color.rgb(210,180,140))

    roof = Entity(model='cube', scale=(7.6,.35,6.6),
                  position=(x,3.35,z), rotation=(0,0,0),
                  color=color.rgb(130,50,45))

    door = Entity(model='cube', scale=(1.2,2.1,.12),
                  position=(x,1.05,z-3.07), color=color.rgb(80,45,25))

def create_world():
    Sky(color=color.rgb(120,190,255))

    ground = Entity(
        model='plane',
        scale=100,
        texture='white_cube',
        texture_scale=(100,100),
        color=color.rgb(85,160,75),
        collider='box'
    )

    # Jalan
    Entity(model='cube', scale=(8,.04,100),
           position=(0,.03,0), color=color.rgb(80,80,80))
    Entity(model='cube', scale=(100,.04,8),
           position=(0,.04,0), color=color.rgb(80,80,80))

    # Rumah
    create_house((14,0,14))
    create_house((-18,0,18))

    # Pohon
    positions = [
        (6,0,12), (10,0,-12), (-8,0,-10),
        (-15,0,-4), (20,0,-8), (-25,0,5),
        (5,0,25), (-8,0,27)
    ]
    for p in positions:
        create_tree(p)

    # Kolam
    Entity(model='cube', scale=(12,.05,8),
           position=(25,.04,25), color=color.rgb(40,130,210))

    # Papan informasi
    board = Entity(model='cube', scale=(5,2.5,.15),
                   position=(0,2,6), color=color.rgb(110,75,40))
    Text("SELAMAT DATANG!", parent=board, y=.2, x=-.42,
         scale=2, color=color.white)
